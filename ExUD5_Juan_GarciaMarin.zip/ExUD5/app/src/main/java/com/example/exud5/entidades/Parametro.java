package com.example.exud5.entidades;

public class Parametro {
  String llave;
  String valor;

  public Parametro() {

  }

  public Parametro(String llave, String valor) {
    this.llave = llave;
    this.valor = valor;
  }

  public String getLlave() {
    return llave;
  }

  public void setLlave(String llave) {
    this.llave = llave;
  }

  public String getValor() {
    return valor;
  }

  public void setValor(String valor) {
    this.valor = valor;
  }
}
