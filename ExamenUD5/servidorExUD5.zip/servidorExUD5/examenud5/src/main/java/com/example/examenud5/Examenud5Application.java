package com.example.examenud5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Examenud5Application {

	public static void main(String[] args) {
		SpringApplication.run(Examenud5Application.class, args);
	}

}
