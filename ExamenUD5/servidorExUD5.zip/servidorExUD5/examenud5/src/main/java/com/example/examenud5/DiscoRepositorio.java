package com.example.examenud5;

import org.springframework.data.repository.CrudRepository;

public interface DiscoRepositorio extends CrudRepository<Disco,Long> {

}
